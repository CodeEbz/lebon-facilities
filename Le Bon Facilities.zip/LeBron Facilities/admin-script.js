// Admin Dashboard JavaScript
let messages = JSON.parse(localStorage.getItem('contactMessages') || '[]');
let currentFilter = 'all';
let selectedMessageId = null;

// Initialize admin panel
document.addEventListener('DOMContentLoaded', function() {
    checkAuth();
    initializeEventListeners();
    loadDashboard();
    
    // Check for new messages periodically
    setInterval(checkForNewMessages, 5000);
});

// Check for new messages
async function checkForNewMessages() {
    if (localStorage.getItem('adminLoggedIn')) {
        await loadMessagesFromAPI();
    }
}

// Authentication
function checkAuth() {
    const isLoggedIn = localStorage.getItem('adminLoggedIn');
    const loginModal = document.getElementById('loginModal');
    
    if (!isLoggedIn) {
        loginModal.style.display = 'flex';
    } else {
        loginModal.style.display = 'none';
        loadMessagesFromAPI();
    }
}

// Event listeners
function initializeEventListeners() {
    // Login form
    document.getElementById('loginForm').addEventListener('submit', handleLogin);
    
    // Navigation
    document.querySelectorAll('.nav-item').forEach(item => {
        item.addEventListener('click', handleNavigation);
    });
    
    // Message filters
    document.querySelectorAll('.filter-btn').forEach(btn => {
        btn.addEventListener('click', handleFilter);
    });
}

// Handle login
async function handleLogin(e) {
    e.preventDefault();
    const username = document.getElementById('username').value;
    const password = document.getElementById('password').value;
    
    try {
        const response = await fetch('/api/admin/login', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ username, password })
        });
        
        if (response.ok) {
            localStorage.setItem('adminLoggedIn', 'true');
            document.getElementById('loginModal').style.display = 'none';
            await loadMessagesFromAPI();
        } else {
            alert('Invalid credentials');
        }
    } catch (error) {
        console.error('Login error:', error);
        alert('Login failed. Please try again.');
    }
}

// Handle navigation
function handleNavigation(e) {
    e.preventDefault();
    const section = e.currentTarget.dataset.section;
    
    // Update active nav item
    document.querySelectorAll('.nav-item').forEach(item => {
        item.classList.remove('active');
    });
    e.currentTarget.classList.add('active');
    
    // Show corresponding section
    document.querySelectorAll('.content-section').forEach(section => {
        section.classList.remove('active');
    });
    document.getElementById(section).classList.add('active');
    
    // Update page title
    const titles = {
        'dashboard': 'Dashboard',
        'messages': 'Messages'
    };
    document.getElementById('pageTitle').textContent = titles[section];
}

// Load dashboard
function loadDashboard() {
    updateStats();
    loadRecentMessages();
}

// Update statistics
function updateStats() {
    const total = messages.length;
    const unread = messages.filter(msg => !msg.read).length;
    const today = messages.filter(msg => {
        const msgDate = new Date(msg.timestamp);
        const todayDate = new Date();
        return msgDate.toDateString() === todayDate.toDateString();
    }).length;
    
    document.getElementById('totalMessages').textContent = total;
    document.getElementById('unreadMessages').textContent = unread;
    document.getElementById('todayMessages').textContent = today;
    document.getElementById('messageCount').textContent = unread;
}

// Load recent messages for dashboard
function loadRecentMessages() {
    const recentMessages = messages
        .sort((a, b) => new Date(b.timestamp) - new Date(a.timestamp))
        .slice(0, 5);
    
    const container = document.getElementById('recentMessagesList');
    
    if (recentMessages.length === 0) {
        container.innerHTML = '<p class="no-messages">No messages yet</p>';
        return;
    }
    
    container.innerHTML = recentMessages.map(msg => `
        <div class="message-preview ${!msg.read ? 'unread' : ''}" onclick="selectMessage('${msg._id}'); showMessagesSection();">
            <div class="message-info">
                <strong>${msg.name}</strong>
                <span class="message-time">${formatDate(msg.timestamp)}</span>
            </div>
            <p class="message-subject">${msg.subject}</p>
            <p class="message-excerpt">${msg.message.substring(0, 100)}...</p>
        </div>
    `).join('');
}

// Show messages section
function showMessagesSection() {
    // Update navigation
    document.querySelectorAll('.nav-item').forEach(item => {
        item.classList.remove('active');
    });
    document.querySelector('[data-section="messages"]').classList.add('active');
    
    // Show messages section
    document.querySelectorAll('.content-section').forEach(section => {
        section.classList.remove('active');
    });
    document.getElementById('messages').classList.add('active');
    
    // Update page title
    document.getElementById('pageTitle').textContent = 'Messages';
}

// Load messages
function loadMessages() {
    displayMessages(getFilteredMessages());
}

// Load messages from API
async function loadMessagesFromAPI() {
    try {
        const response = await fetch('/api/messages');
        if (response.ok) {
            messages = await response.json();
            updateStats();
            loadRecentMessages();
            if (document.getElementById('messages').classList.contains('active')) {
                loadMessages();
            }
        }
    } catch (error) {
        console.error('Error loading messages:', error);
    }
}

// Mark message as read
async function markMessageAsRead(messageId) {
    try {
        await fetch(`/api/messages/${messageId}/read`, {
            method: 'PATCH'
        });
    } catch (error) {
        console.error('Error marking message as read:', error);
    }
}

// Get filtered messages
function getFilteredMessages() {
    switch(currentFilter) {
        case 'unread':
            return messages.filter(msg => !msg.read);
        case 'read':
            return messages.filter(msg => msg.read);
        default:
            return messages;
    }
}

// Handle message filter
function handleFilter(e) {
    currentFilter = e.target.dataset.filter;
    
    // Update active filter button
    document.querySelectorAll('.filter-btn').forEach(btn => {
        btn.classList.remove('active');
    });
    e.target.classList.add('active');
    
    // Display filtered messages
    displayMessages(getFilteredMessages());
}

// Display messages
function displayMessages(messagesToShow) {
    const container = document.getElementById('messagesList');
    
    if (messagesToShow.length === 0) {
        container.innerHTML = '<p class="no-messages">No messages found</p>';
        return;
    }
    
    container.innerHTML = messagesToShow
        .sort((a, b) => new Date(b.timestamp) - new Date(a.timestamp))
        .map(msg => `
            <div class="message-item ${!msg.read ? 'unread' : ''}" onclick="selectMessage('${msg._id}')">
                <div class="message-header">
                    <strong>${msg.name}</strong>
                    <span class="message-time">${formatDate(msg.timestamp)}</span>
                </div>
                <div class="message-subject">${msg.subject}</div>
                <div class="message-preview">${msg.message.substring(0, 100)}...</div>
                <div class="message-contact">
                    <i class="fas fa-envelope"></i> ${msg.email}
                    <i class="fas fa-phone"></i> ${msg.phone}
                </div>
            </div>
        `).join('');
}

// Select and display message details
async function selectMessage(messageId) {
    selectedMessageId = messageId;
    const message = messages.find(msg => msg._id === messageId);
    
    if (!message) return;
    
    // Mark as read
    if (!message.read) {
        message.read = true;
        await markMessageAsRead(messageId);
        updateStats();
        loadMessages(); // Refresh the list
    }
    
    // Display message details
    const detailContainer = document.getElementById('messageDetail');
    detailContainer.innerHTML = `
        <div class="message-full">
            <div class="message-full-header">
                <h3>${message.subject}</h3>
                <div class="message-actions">
                    <button onclick="deleteMessage('${message._id}')" class="btn-delete">
                        <i class="fas fa-trash"></i> Delete
                    </button>
                </div>
            </div>
            <div class="message-meta">
                <div class="sender-info">
                    <strong>${message.name}</strong>
                    <span>${message.email}</span>
                    <span>${message.phone}</span>
                </div>
                <div class="message-date">${formatDate(message.timestamp)}</div>
            </div>
            <div class="message-body">
                ${message.message.replace(/\n/g, '<br>')}
            </div>
        </div>
    `;
}

// Delete message
async function deleteMessage(messageId) {
    if (confirm('Are you sure you want to delete this message?')) {
        try {
            const response = await fetch(`/api/messages/${messageId}`, {
                method: 'DELETE'
            });
            
            if (response.ok) {
                // Remove from local array
                messages = messages.filter(msg => msg._id !== messageId);
                
                // Clear message detail view
                document.getElementById('messageDetail').innerHTML = `
                    <div class="no-message-selected">
                        <i class="fas fa-envelope"></i>
                        <p>Select a message to view details</p>
                    </div>
                `;
                
                // Refresh displays
                updateStats();
                loadMessages();
                loadRecentMessages();
            }
        } catch (error) {
            console.error('Error deleting message:', error);
            alert('Failed to delete message');
        }
    }
}

// Format date
function formatDate(timestamp) {
    const date = new Date(timestamp);
    const now = new Date();
    const diffTime = Math.abs(now - date);
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
    
    if (diffDays === 1) {
        return 'Today ' + date.toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'});
    } else if (diffDays === 2) {
        return 'Yesterday ' + date.toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'});
    } else if (diffDays <= 7) {
        return date.toLocaleDateString([], {weekday: 'short'}) + ' ' + date.toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'});
    } else {
        return date.toLocaleDateString() + ' ' + date.toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'});
    }
}

// Logout function
function logout() {
    if (confirm('Are you sure you want to logout?')) {
        localStorage.removeItem('adminLoggedIn');
        location.reload();
    }
}